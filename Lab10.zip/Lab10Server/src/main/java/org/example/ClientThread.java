package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientThread extends Thread {
    private Socket socket = null;
    private GameServer server = null;

    public ClientThread(Socket socket, GameServer server) {
        this.socket = socket;
        this.server = server;
    }

    public void run() {
        boolean clientStillConnected = true;
        try {
            while (clientStillConnected) {
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));
                String request = in.readLine();
                if (!request.equals("exit") && !request.equals("stop")) {
                    PrintWriter out = new PrintWriter(socket.getOutputStream());
                    System.out.println("Trimit urmatorul raspuns catre client: " + request + " primit cu succes");
                    String raspuns = "" + request + " primit cu succes";
                    out.println(raspuns);
                    out.flush();
                } else if (request.equals("stop")) {
                    server.stopServer();
                } else {
                    System.out.println("Clientul a inchis conexiunea. Asteptam alt client.");
                    clientStillConnected = false;
                }
            }
        } catch (IOException e) {
            System.err.println("Communication error... " + e);
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                System.err.println(e);
            }
        }
    }
}

