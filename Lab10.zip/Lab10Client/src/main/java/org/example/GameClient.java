package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class GameClient {
    String serverAddress = "127.0.0.1";
    int PORT = 8100;
    boolean done = false;

    public GameClient() throws IOException {
        try {
            Socket socket = new Socket(serverAddress, PORT);
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter any command (exit closes the connection):");
            while (!done) {
                String command = scanner.nextLine();
                PrintWriter out =
                        new PrintWriter(socket.getOutputStream(), true);
                out.println(command);
                if (!command.equals("exit")) {
                    System.out.println("Sent the following command to server: " + command);
                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(socket.getInputStream()));
                    String response = in.readLine();
                    if(response != null)
                        System.out.println("Am primit urmatorul raspuns: " + response);
                    else System.out.println("Serverul e inchis.");
                } else {
                    System.out.println("I just left the server. Goodbye.");
                    done = true;
                }
            }
        } catch (UnknownHostException e) {
            System.err.println("No server listening... " + e);
        }
    }
}
