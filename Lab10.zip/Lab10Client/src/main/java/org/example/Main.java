package org.example;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        GameClient client = new GameClient();
    }
}