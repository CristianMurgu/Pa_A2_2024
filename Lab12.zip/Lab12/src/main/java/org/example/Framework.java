package org.example;

import java.lang.reflect.*;

public class Framework {
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.out.println("Introduceti numele clasei drept argument.");
            return;
        }

        Class<?> clazz = Class.forName(args[0]);

        System.out.println("Clasa: " + clazz.getSimpleName());
        System.out.println("Metode:");
        Method[] methods = clazz.getDeclaredMethods();
        for (Method method : methods) {
            System.out.println("  - " + method.getName() + "()");
        }

        int passed = 0, failed = 0;
        for (Method method : methods) {
            if (method.isAnnotationPresent(Test.class)) {
                try {
                    method.invoke(null);
                    passed++;
                    System.out.println("Test '" + method.getName() + "' passed.");
                } catch (InvocationTargetException ex) {
                    System.out.println("Test '" + method.getName() + "' failed: " + ex.getCause().getMessage());
                    failed++;
                }
            }
        }

        System.out.printf("Tests Passed: %d, Failed: %d%n", passed, failed);
    }
}
